import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  email = '';
  password = '';
  error: string | null = null;

  constructor(private authService: AuthService, private router: Router) { }

  onLogin(): void {
    this.authService.login(this.email, this.password).subscribe(
      (response) => {
        // Navigate to user details page and pass the response data
        this.router.navigate(['/user-details'], { 
          state: { 
            data: { email: this.email, password: this.password } 
          } 
        });
      },
      (error) => {
        this.error = 'Login failed, please check your credentials.';
      }
    );
  }
}
